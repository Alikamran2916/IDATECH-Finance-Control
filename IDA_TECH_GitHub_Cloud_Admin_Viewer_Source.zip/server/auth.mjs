import {randomBytes, scryptSync, timingSafeEqual, createHash} from 'node:crypto';
const sha=x=>createHash('sha256').update(x).digest('hex');
const hashPassword=p=>{const salt=randomBytes(16).toString('hex');return `scrypt:${salt}:${scryptSync(p,salt,64).toString('hex')}`;};
const verify=(password,stored)=>{try{const [kind,salt,key]=stored.split(':');if(kind!=='scrypt')return false;const calculated=scryptSync(password,salt,64),existing=Buffer.from(key,'hex');return existing.length===calculated.length&&timingSafeEqual(calculated,existing);}catch{return false;}};
const cookie=(req,name)=>{const match=String(req.headers.cookie||'').match(new RegExp('(?:^|;\\s*)'+name+'=([^;]*)'));return match?.[1]||''};
export function createAuth(db){
 db.exec(`CREATE TABLE IF NOT EXISTS app_users(id INTEGER PRIMARY KEY AUTOINCREMENT,email TEXT UNIQUE NOT NULL,password_hash TEXT NOT NULL,role TEXT NOT NULL CHECK(role IN ('admin','viewer')),active INTEGER NOT NULL DEFAULT 1,created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);
 CREATE TABLE IF NOT EXISTS app_sessions(token_hash TEXT PRIMARY KEY,user_id INTEGER NOT NULL REFERENCES app_users(id),csrf_hash TEXT NOT NULL,expires_at INTEGER NOT NULL);
 CREATE INDEX IF NOT EXISTS sessions_exp ON app_sessions(expires_at);`);
 const initialEmail=String(process.env.IDA_ADMIN_EMAIL||'').toLowerCase().trim(),initialPass=String(process.env.IDA_ADMIN_PASSWORD||'');
 if(!db.prepare('SELECT id FROM app_users WHERE role=\'admin\' LIMIT 1').get()){
  if(!initialEmail||initialPass.length<14)throw Error('First startup requires IDA_ADMIN_EMAIL and IDA_ADMIN_PASSWORD (14+ characters). Set these as secrets, never in GitHub.');
  db.prepare('INSERT INTO app_users(email,password_hash,role) VALUES(?,?,?)').run(initialEmail,hashPassword(initialPass),'admin');
 }
 const failed=new Map();
 const clear=()=>db.prepare('DELETE FROM app_sessions WHERE expires_at<?').run(Date.now());
 const lookup=req=>{const token=cookie(req,'ida_session');if(!/^[a-f0-9]{64}$/.test(token))return null;const row=db.prepare('SELECT s.*,u.email,u.role,u.active FROM app_sessions s JOIN app_users u ON u.id=s.user_id WHERE s.token_hash=? AND s.expires_at>?').get(sha(token),Date.now());return row?.active?{id:row.user_id,email:row.email,role:row.role,csrf_hash:row.csrf_hash}:null;};
 const secure=req=>process.env.IDA_SECURE_COOKIES==='1'||req.socket.encrypted===true||req.headers['x-forwarded-proto']==='https';
 return {
  current(req){const u=lookup(req);return u?{id:u.id,email:u.email,role:u.role}:null;},
  csrf(req){return cookie(req,'ida_csrf');},
  checkCsrf(req){const u=lookup(req),provided=String(req.headers['x-csrf-token']||'');return Boolean(u&&/^[a-f0-9]{64}$/.test(provided)&&sha(provided)===u.csrf_hash);},
  login(req,res,body,json){const ip=String(req.socket.remoteAddress||'local'),now=Date.now(),attempt=failed.get(ip)||{n:0,until:0};if(attempt.until>now)return json(res,{error:'Too many attempts. Try again later.'},429);
   const email=String(body.email||'').toLowerCase().trim(),pwd=String(body.password||'');const user=db.prepare('SELECT * FROM app_users WHERE email=? AND active=1').get(email);
   if(!user||!verify(pwd,user.password_hash)){attempt.n++;attempt.until=attempt.n>=5?now+15*60_000:0;failed.set(ip,attempt);return json(res,{error:'Invalid email or password'},401);}failed.delete(ip);clear();const token=randomBytes(32).toString('hex'),csrf=randomBytes(32).toString('hex');db.prepare('INSERT INTO app_sessions(token_hash,user_id,csrf_hash,expires_at) VALUES(?,?,?,?)').run(sha(token),user.id,sha(csrf),now+8*60*60_000);
   const opts=`Path=/; SameSite=Strict${secure(req)?'; Secure':''}`;res.setHeader('Set-Cookie',[`ida_session=${token}; HttpOnly; ${opts}; Max-Age=28800`,`ida_csrf=${csrf}; ${opts}; Max-Age=28800`]);return json(res,{ok:true,role:user.role});},
  logout(req,res,json){const token=cookie(req,'ida_session');if(token)db.prepare('DELETE FROM app_sessions WHERE token_hash=?').run(sha(token));res.setHeader('Set-Cookie',['ida_session=; Path=/; Max-Age=0; HttpOnly; SameSite=Strict','ida_csrf=; Path=/; Max-Age=0; SameSite=Strict']);return json(res,{ok:true});},
  listUsers(){return db.prepare('SELECT id,email,role,active,created_at FROM app_users ORDER BY id').all();},
  addUser(body){const email=String(body.email||'').trim().toLowerCase(),password=String(body.password||'');if(!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)||password.length<14)throw Error('Valid email and password of at least 14 characters required');const role=body.role==='admin'?'admin':'viewer';const r=db.prepare('INSERT INTO app_users(email,password_hash,role) VALUES(?,?,?)').run(email,hashPassword(password),role);return {id:Number(r.lastInsertRowid),email,role};},
  setUser(id,body,actor){const row=db.prepare('SELECT * FROM app_users WHERE id=?').get(id);if(!row)throw Error('User not found');if(id===actor&&body.active===false)throw Error('Cannot deactivate yourself');if(body.active!==undefined){db.prepare('UPDATE app_users SET active=? WHERE id=?').run(body.active?1:0,id);if(!body.active)db.prepare('DELETE FROM app_sessions WHERE user_id=?').run(id);}if(body.password!==undefined){const pwd=String(body.password);if(pwd.length<14)throw Error('Password must be at least 14 characters');db.prepare('UPDATE app_users SET password_hash=? WHERE id=?').run(hashPassword(pwd),id);db.prepare('DELETE FROM app_sessions WHERE user_id=?').run(id);}return {ok:true};}
 };
}
