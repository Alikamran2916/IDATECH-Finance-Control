# IDA TECH — Cloud Petty Cash & Subsidiary Ledger System

Full application source for GitHub + an always-on Linux host (for example, Oracle Cloud Always Free). **GitHub Pages by itself cannot host this server-side application.** See `GITHUB_DEPLOY_GUIDE.md` for setup.

## Includes
- Master petty cash and account-specific subsidiary ledgers with automatic reciprocal references
- Four account heads: Owner (Osama), Third Party (D4Tech.Ausaf/Sameer), Employees (including Restream Panel), Expenses
- Employee renames: Rabeet, Abdul Wasay, Sohaib
- Split funding, edit/void, audit, search, Excel/PDF exports, zero historical starting balances dated 1 Dec 2026
- Session-based Admin/Viewer logins with server-side write authorization, CSRF protection and secure cookies over HTTPS
- Admin user management (add/deactivate accounts)
- Shared database with ten-second automatic screen refresh

## Server requirements
Docker + Compose and a persistent volume; environment variables `IDA_ADMIN_EMAIL`, `IDA_ADMIN_PASSWORD` (14+ chars; recommend 20+ random), `IDA_SECURE_COOKIES=1` for public HTTPS. Run `docker compose up -d --build` with real `.env` file from `.env.example`.

The service binds to `127.0.0.1:8787` on the host; use a private HTTPS proxy/tunnel. Keep `.env`, SQLite files, financial data, SSH keys and backups **out of GitHub**. See guide for deployment, update and backups.

**Status:** Local API authentication and viewer permission smoke tests passed. Production deployment, TLS, backup restore and user-acceptance tests are not yet performed. Independent security review is recommended before storing live company financial data.
