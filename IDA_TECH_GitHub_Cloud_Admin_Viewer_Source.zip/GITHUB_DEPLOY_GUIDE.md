# IDA TECH — GitHub + Oracle Cloud deployment

**GitHub is the repository, not the always-on server.** GitHub Pages cannot run Node.js + SQLite. Upload this *source* as a private GitHub repository and deploy to Oracle Cloud VM (or a hosting provider with persistent disk).

## 1. Protect the database
- Never upload `data/`, `.env`, passwords, SSH keys or real financial records. `.gitignore` excludes them.
- You can preserve localhost transactions by moving database backups privately to the server, **not through GitHub**. If you want a fresh start, leave DB empty.

## 2. GitHub
1. Create a PRIVATE GitHub repository `ida-tech-ledger`.
2. Upload all project files (`server`, `web`, `Dockerfile`, `compose.yaml`, `.env.example`, etc.). Do **not** upload local `data` or `.env`.
3. Keep `main` branch; pushing subsequent changes updates GitHub source only (deployment/restart is still needed unless CI/CD is configured).

## 3. Oracle Always Free VM
1. Create an Always Free eligible Ubuntu VM with sufficient capacity (ARM A1 Flex works with multiarch `node:24-bookworm-slim` image).
2. SSH to your VM. Install Docker Engine and Docker Compose plugin from Docker's official repository. Configure firewall to permit SSH and HTTPS only.
3. `git clone https://github.com/YOUR_USERNAME/ida-tech-ledger.git` (for private repo, authenticate with GitHub SSH deploy key or a fine-grained token, not a password).
4. `cd ida-tech-ledger && cp .env.example .env && nano .env`
5. Set real private `IDA_ADMIN_EMAIL`, unique `IDA_ADMIN_PASSWORD` of 20+ chars, `IDA_SECURE_COOKIES=1`. Don't commit `.env`.
6. `docker compose up -d --build` . App is **only** listening on VM loopback `127.0.0.1:8787`, not public.
7. Configure Cloudflare Tunnel with origin `http://127.0.0.1:8787` and hostname attached to your domain. Restrict access via Cloudflare Access policies (separate layer). Enable HTTPS. Set up persistent DNS/hostname.
8. Open HTTPS URL, sign in with admin credentials. In **Manage Users**, add your managers with `viewer` role and share initial passwords separately. Manager APIs will reject writes (HTTP 403).

## 4. Deploy code updates
`git pull --ff-only && docker compose up -d --build`
Data is kept in persistent named volume `ida_tech_data`. Do not run `docker compose down -v` because `-v` destroys volume data.

## 5. Live sync
Web clients refresh approximately every 10 seconds while their tab is active (polling), not immediate push. Admin writes go to same server and are visible to viewers on next poll.

## 6. Backups and operational risk
- Oracle Always Free resource availability is not guaranteed and instances may be reclaimed.
- Schedule daily off-VM backup of SQLite (use `sqlite3 .backup`, SQLite backup API or a stopped-service copy) and periodically test restore.
- Protect VM OS, accounts, Cloudflare Access and GitHub. HTTPS only for users; no direct public 8787 ingress.
- The first admin account is seeded from env vars **only on fresh database**. To rotate existing admin password, use user management or a future reset workflow.
- This is a reference small-team deployment; get professional security/accounting review before entering sensitive live financial data.
